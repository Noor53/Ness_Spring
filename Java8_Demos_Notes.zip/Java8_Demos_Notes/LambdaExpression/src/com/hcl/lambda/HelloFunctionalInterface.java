package com.hcl.lambda;

@FunctionalInterface
public interface HelloFunctionalInterface {

	
	public int findLength(String name);
	
}
